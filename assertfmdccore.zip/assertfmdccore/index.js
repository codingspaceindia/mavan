const functions = require("firebase-functions");

const express = require("express");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const PORT = 3000;
const dbUrl = "mongodb+srv://freeminerscoin:Codingspaceindia@2304@clusterfree.zwwrtqr.mongodb.net/test";

const api = require("./functions/routes/api");

// const rNews = require("./routes/rNews");
const tokenMiddleware = require("./functions/middlewares/tokenMiddleware");

app.get("/", (req, res) => {
  res.send("Hello");
});

app.use(cors());
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use(bodyParser.json({limit: "50mb"}));
app.use(bodyParser.urlencoded({
  limit: "50mb",
  extended: true, parameterLimit: 50000,
}));

app.use(tokenMiddleware);

app.use("/free-coin", api);

// useFindAndModify: false
mongoose.connect(dbUrl, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}, (err, succ) => {
  if (err) {
    console.log("Db not connected");
    console.log(err);
  } else {
    console.log("MongoDB Atlas connected");
  }
});

app.listen(PORT, () => {
  console.log("Server started at", PORT);
});

exports.app = functions.https.onRequest(app);
